# Moon Lotus Academy

Bu paket Vercel ve GitHub için hazırdır.

Klasörün içindeki dosyaları GitHub deposunun ana sayfasına yükleyin:
- index.html
- vercel.json

Dosyalar klasörün içinde kalmamalı; deponun en üst seviyesinde görünmelidir.
